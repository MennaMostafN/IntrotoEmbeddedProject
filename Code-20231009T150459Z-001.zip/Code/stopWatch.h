#include <stdio.h>
#include "bitwise_operation.h"
#include "Keypad.h"
#include <math.h>
#include "LCD.h"



 


void Display();
void initStopWatch();

void stopWatch(void);
void stopWatchInit();