#include <stdio.h>
#include "bitwise_operation.h"
#include "Keypad.h"
#include <math.h>
#include "LCD.h"



void TimerDisplay();
void ReloadValue();
void TimerHandler();
void initTimer();
void PushTime(char key);
void CalcSec();
void TimerInit();
void initTimer1();
void StartTimer1(void);
void Timer(void);