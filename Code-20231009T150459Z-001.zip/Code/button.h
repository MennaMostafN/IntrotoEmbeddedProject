#include "DIO.h"

void ButtonInit();
int ButtonCheck();