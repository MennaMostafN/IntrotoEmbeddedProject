#include "Keypad.h"

#include <stdio.h>
#include <math.h>
#include "LCD.h"



void Push(char key);
double Calc();
void calculatorInit();

void calculator(void);